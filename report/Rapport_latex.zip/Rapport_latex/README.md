# Template for reports and articles

This is a LaTeX template for reports and articles.
Part of this template has been taken from the [`sleek`](https://fr.overleaf.com/latex/templates/sleek-template/hrksrrdywhfk) template found on [Overleaf](https://www.overleaf.com)
However the base classes are not the same.
The base class for articles is `elsarticle` and the base class for reports is `memoir`.

## How to use it

You must copy this folder with all the files.
Adjust your content in each part.
Obviously you can adapt the plan, but all the sections listed are a good start for any normal report or article.

You can compile a report or an article from the very same files.
An option to the class makes the switch:

```latex
\documentclass[article]{cei}
% article document
```

```latex
\documentclass[report]{cei}
% report document
```

With fourier fonts (default), you can used `pdflatex`. Other fonts may require `xelatex` or `lualatex`.

## What's in it

Fonts are fourier by default, with the option to use libertine or palatino.
The option is:
```latex
\documentclass[...,font=libertine]{cei}
```

Another option is `french` which will load babel in "french" mode, but also adjust other things.

By default, paper size is A4 and font size is 10pt.

This is the list of packages that are loaded by this class:

- amsmath, amssymb, amsthm, array, babel, bm, booktabs, 
- calc, caption, cleveref, csquotes, enumitem, esint, 
- etoolbox, eurosym, float, fontenc, fontspec, fourier, 
- fp, geometry, graphicx, hyperref, ifluatex, ifpdf, 
- inputenc, lmodern, mdframed, multicol, multirow, 
- pdftexcmds, pifont, rotating, siunitx, stmaryrd, 
- subcaption, textcomp, ulem, unicode-math, url, 
- xcolor, xfrac

You are welcome to load anything that is not in this list.

## Next steps

- provide a pandoc markdown template